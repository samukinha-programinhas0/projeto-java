package controllers;

import models.contato;
import repository.contatoRepository;
import views.contatoform;
import views.contatoTableView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class contatocontroller {
    private contatoRepository repository;
    private contatoTableView tableView;
    
    public contatocontroller() {
        repository = new contatoRepository();
        tableView = new contatoTableView();
        inicializar();
    }

private void inicializar() {
        // Atualizar a tabela com os contatos existentes
        atualizarTabela();

        // Criar a barra de ferramentas (toolbar) com botões
        JToolBar toolBar = new JToolBar();
        JButton adicionarButton = new JButton("Adicionar");
        JButton editarButton = new JButton("Editar");
        JButton deletarButton = new JButton("Deletar");
        toolBar.add(adicionarButton);
        toolBar.add(editarButton);
        toolBar.add(deletarButton);

        tableView.add(toolBar, java.awt.BorderLayout.NORTH);

        // Ações dos botões
        adicionarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarContato();
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarContato();
            }
        });

        deletarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletarContato();
            }
        });

        tableView.setVisible(true);
    }

private void atualizarTabela() {
        List<contato> contatos = repository.obterTodosContatos();
        tableView.atualizarTabela(contatos);
    }

    private void adicionarContato() {
        contatoform form = new contatoform (tableView, "Adicionar Contato");
        form.setVisible(true);
        contato novoContato = form.getContato();
        if (novoContato != null) {
            repository.adicionarContato (novoContato);
            atualizarTabela();
        }
    }

    private void editarContato() {
            int selectedId = tableView.getSelectedContatoId();
            if (selectedId != -1) {
                contato contato = repository.obterContatoPorId (selectedId);
                if (contato != null) {
                    contatoform form = new contatoform (tableView, 
                        "Editar Contato", contato);
                    form.setVisible(true);
                    contato contatoAtualizado = form.getContato();
                    if (contatoAtualizado != null) {
                        contatoAtualizado = new contato(
                            selectedId,
                            contatoAtualizado.getNome(),
                            contatoAtualizado.getEmail(),
                            contatoAtualizado.getTelefone()
                        );
                        repository.atualizarContato (contatoAtualizado);
                        atualizarTabela();
                    }
                } else {
                    JOptionPane.showMessageDialog(tableView,
                        "Contato não encontrado.",
                        "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(tableView,
                    "Selecione um contato para editar.",
                    "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        }

private void deletarContato() {
        int selectedId = tableView.getSelectedContatoId();
        if (selectedId != -1) {
            int confirm = JOptionPane.showConfirmDialog(
                tableView,
                "Tem certeza que deseja deletar este contato?",
                "Confirmar Deleção",
                JOptionPane. YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                repository.deletarContato (selectedId);
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(
                tableView,
                "Selecione um contato para deletar.",
                "Aviso",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    public void iniciar() {
        // Ações já são inicializadas no construtor
    }
}