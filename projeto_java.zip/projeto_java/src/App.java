import controllers.contatocontroller;

public class App {
    public static void main(String[] args) throws Exception {
        contatocontroller controller = new contatocontroller();
        controller.iniciar();
    }
}