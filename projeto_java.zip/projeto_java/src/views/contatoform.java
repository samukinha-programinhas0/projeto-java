package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;
import models.contato;

public class contatoform extends JDialog {
    private JTextField nomeField;
    private JTextField emailField;
    private JTextField telefoneField;
    private JButton salvarButton;
    private JButton cancelarButton;

    private contato contato;
    private boolean isEditMode;

    public contatoform(Frame parent, String title) {
        super (parent, title, true);
        this.isEditMode = false;
        initializeComponents();
    }

    public contatoform(Frame parent, String title, contato contato) {
        super (parent, title, true);
        this.contato = contato;
        this.isEditMode = true;
        initializeComponents();
        preencherCampos();
    }

private void initializeComponents() {
        nomeField = new JTextField(20);
        emailField = new JTextField(20);
        telefoneField = new JTextField(20);
        salvarButton = new JButton("Salvar");
        cancelarButton = new JButton("Cancelar");

        JPanel panel = new JPanel (new GridLayout (4, 2, 10, 10));
        panel.add(new JLabel("Nome:"));
        panel.add(nomeField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Telefone:"));
        panel.add(telefoneField);
        panel.add(salvarButton);
        panel.add(cancelarButton);

    // Adicionando uma margem de 10 pixels nas bordas laterais e verticais
    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
    salvarButton.addActionListener((ActionEvent e) -> {
        if (validarCampos()) {
            if (isEditMode) {
                atualizarContato();
            } else {
                adicionarContato();
            }
            dispose();
        }
        });
    
    cancelarButton.addActionListener(e -> dispose());
    
    this.add(panel);
    this.pack();
    this.setLocationRelativeTo(getParent());
}

private void preencherCampos() {
        if (contato != null) {
            nomeField.setText(contato.getNome());
            emailField.setText(contato.getEmail());
            telefoneField.setText(contato.getTelefone());
        }
    }

    private boolean validarCampos() {
        if (nomeField.getText().trim().isEmpty() ||
            emailField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Nome e Email são obrigatórios.",
                "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void adicionarContato() {
        contato = new contato(
                nomeField.getText().trim(), 
                emailField.getText().trim(), 
                telefoneField.getText().trim()
        );
    }

    private void atualizarContato() {
        if (contato != null) {
            contato.setNome (nomeField.getText().trim());
            contato.setEmail(emailField.getText().trim());
            contato.setTelefone (telefoneField.getText().trim());
        }
    }

    public contato getContato() {
        return contato;
    }
}