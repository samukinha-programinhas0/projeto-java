package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;
import models.Filmes;

public class FilmesForm extends JDialog {
    private JTextField nomeField;
    private JTextField generoField;
    private JTextField diretorField;
    private JTextField faixaEtariaField;
    private JTextField dataField;
    private JTextField disponivelField;
    private JButton salvarButton;
    private JButton cancelarButton;

    private Filmes Filme;
    private boolean isEditMode;

    public FilmesForm(Frame parent, String title) {
        super (parent, title, true);
        this.isEditMode = false;
        initializeComponents();
    }

    public FilmesForm(Frame parent, String title, Filmes Filme) {
        super (parent, title, true);
        this.Filme = Filme;
        this.isEditMode = true;
        initializeComponents();
        preencherCampos();
    }

private void initializeComponents() {
        nomeField = new JTextField(20);
        generoField = new JTextField(20);
        diretorField = new JTextField(20);
        faixaEtariaField = new JTextField(20);
        dataField = new JTextField(20);
        disponivelField = new JTextField(20);
        salvarButton = new JButton("Salvar");
        cancelarButton = new JButton("Cancelar");

        JPanel panel = new JPanel (new GridLayout (4, 2, 10, 10));
        panel.add(new JLabel("Nome:"));
        panel.add(nomeField);
        panel.add(new JLabel("genero:"));
        panel.add(generoField);
        panel.add(new JLabel("diretor:"));
        panel.add(diretorField);
        panel.add(new JLabel("faixaEtaria:"));
        panel.add(faixaEtariaField);
        panel.add(new JLabel("data:"));
        panel.add(dataField);
        panel.add(new JLabel("disponivel:"));
        panel.add(disponivelField);
        panel.add(salvarButton);
        panel.add(cancelarButton);

    // Adicionando uma margem de 10 pixels nas bordas laterais e verticais
    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
    salvarButton.addActionListener((ActionEvent e) -> {
        if (validarCampos()) {
            if (isEditMode) {
                atualizarFilme();
            } else {
                adicionarFilme();
            }
            dispose();
        }
        });
    
    cancelarButton.addActionListener(e -> dispose());
    
    this.add(panel);
    this.pack();
    this.setLocationRelativeTo(getParent());
}

private void preencherCampos() {
        if (Filme != null) {
            nomeField.setText(Filme.getNome());
            generoField.setText(Filme.getGenero());
            diretorField.setText(Filme.getDiretor());
            faixaEtariaField.setText(Filme.getFaixaEtaria());
            dataField.setText(Filme.getData());
            disponivelField.setText(Filme.getDisponivel());
        }
    }

    private boolean validarCampos() {
        if (nomeField.getText().trim().isEmpty() ||
            disponivelField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "nome e disponibilidade obrigatórios.",
                "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void adicionarFilme() {
        Filme = new Filmes(
                nomeField.getText().trim(), 
                generoField.getText().trim(), 
                diretorField.getText().trim(),
                faixaEtariaField.getText().trim(),
                dataField.getText().trim(),
                disponivelField.getText().trim()
        );
    }

    private void atualizarFilme() {
        if (Filme != null) {
            Filme.setNome (nomeField.getText().trim());
            Filme.setGenero(generoField.getText().trim());
            Filme.setDiretor (diretorField.getText().trim());
            Filme.setFaixaEtaria (faixaEtariaField.getText().trim());
            Filme.setData (dataField.getText().trim());
            Filme.setDisponivel (disponivelField.getText().trim());
        }
    }

    public Filmes getFilme() {
        return Filme;
    }
}